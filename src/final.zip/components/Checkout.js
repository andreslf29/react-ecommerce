import React from "react";
import CartForm from "./Cart/CartForm";

function Checkout() {
  return (
    <div>
      <CartForm />
    </div>
  );
}

export default Checkout;
